Perform the following steps in Android Studio:

1. In the Android Studio welcome screen click “Open an existing Android Studio project”. Point to the unpacked ‘ExampleTestProject_AndroidStudio’ folder. 

2. Android Studio will now open the project. 

3. (If needed) go to Tools —> Android —> Sync Project with Gradle Files.

4. In the Project window find ‘NotePadTest.java’ in app/src/androidTest/java/com.example.android.notepad/. Right click NotePadTest.java and select ‘Run NotePadTest’.  


For Robotium tutorials:

https://github.com/RobotiumTech/robotium/wiki/Robotium-Tutorials


Record tests with Robotium Recorder:

http://robotium.com/


